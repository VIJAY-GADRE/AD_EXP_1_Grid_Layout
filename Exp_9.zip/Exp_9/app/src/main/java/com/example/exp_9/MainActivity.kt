package com.example.exp_9

import android.os.Bundle
import android.content.Context
import android.os.Message
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.*
import java.lang.StringBuilder

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var read: Button
    private lateinit var write: Button
    private lateinit var userInput: EditText
    private lateinit var fileContent: TextView

    private val fileName = "demoFile.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        read = findViewById(R.id.button_read)
        write = findViewById(R.id.button_write)
        userInput = findViewById(R.id.user_input)
        fileContent = findViewById(R.id.contents)

        read.setOnClickListener(this)
        write.setOnClickListener(this)
    }

    private fun printMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onClick(view: View?) {
        val b = view as Button?
        val bText = b?.text.toString().toLowerCase()

        when (bText) {
            "write" -> writeData()
            "read" -> readData()
        }
    }

    private fun writeData() {
        try {
            val fos = openFileOutput(fileName, Context.MODE_PRIVATE)
            val data = userInput.text.toString()
            fos.write(data.toByteArray())
            fos.flush()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        userInput.setText("")
        printMessage("Writing to the file $fileName completed...")
    }

    private fun readData() {
        try {
            val fin = openFileInput(fileName)
            var a: Int
            val temp = StringBuilder()
            while (fin.read().also { a = it } != -1) {
                temp.append(a.toChar())
            }

            fileContent.text = temp.toString()
            fin.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        printMessage("Reading to the file $fileName completed...")
    }
}