package com.example.exp_9_external_storage

import android.os.*
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.*

class MainActivity : AppCompatActivity() {

    private val filepath = "MyFileStorage"

    private val isExternalStorageReadOnly: Boolean
        get() {
            val extStorageState = Environment.getExternalStorageState()
            return Environment.MEDIA_MOUNTED_READ_ONLY == extStorageState
        }

    private val isExternalStorageAvailable: Boolean
        get() {
            val extStorageState = Environment.getExternalStorageState()
            return Environment.MEDIA_MOUNTED == extStorageState
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val fileName = findViewById<EditText>(R.id.editTextFile)
        val fileData = findViewById<EditText>(R.id.editTextData)
        val saveButton = findViewById<Button>(R.id.button_save)
        val viewButton = findViewById<Button>(R.id.button_view)

        saveButton.setOnClickListener {
            val myExternalFile = File(getExternalFilesDir(filepath), fileName.text.toString())
            try {
                FileOutputStream(myExternalFile).use { fileOutputStream ->
                    fileOutputStream.write(fileData.text.toString().toByteArray())
                }
                Toast.makeText(applicationContext, "Data saved", Toast.LENGTH_SHORT).show()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }

        viewButton.setOnClickListener {
            val filename = fileName.text.toString()
            if (filename.isNotBlank()) {
                val myExternalFile = File(getExternalFilesDir(filepath), filename)
                if (myExternalFile.exists()) {
                    try {
                        FileInputStream(myExternalFile).use { fileInputStream ->
                            val bufferedReader = BufferedReader(InputStreamReader(fileInputStream))
                            val stringBuilder = StringBuilder()
                            var text: String?
                            while (bufferedReader.readLine().also { text = it } != null) {
                                stringBuilder.append(text)
                            }
                            Toast.makeText(applicationContext, stringBuilder.toString(), Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                } else {
                    Toast.makeText(applicationContext, "File not found", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(applicationContext, "Enter a valid file name", Toast.LENGTH_SHORT).show()
            }
        }

        if (!isExternalStorageAvailable || isExternalStorageReadOnly) {
            saveButton.isEnabled = false
        }
    }
}