package com.example.exp_5

import android.os.Bundle
import android.os.Message
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var button_pop_up: Button
    private lateinit var button_option: Button
    private lateinit var button_context: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button_pop_up = findViewById(R.id.button_pop_up)
        button_option = findViewById(R.id.button_option)
        button_context = findViewById(R.id.button_context)

        button_pop_up.setOnClickListener {
            showPopupDialog(it)
        }

        button_option.setOnClickListener {
            showOptionMenu(it)
        }

        button_context.setOnClickListener {
            showContextMenu(it)
        }
    }

    private fun showPopupDialog(v: View) {
        val builder = AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.activity_pop_up, null)
        builder.setView(dialogView)

        val alertDialog = builder.create()
        alertDialog.show()

        val button_close_popup: Button = dialogView.findViewById(R.id.button_close_pop)
        button_close_popup.setOnClickListener {
            alertDialog.dismiss()
        }
    }

    private fun showOptionMenu(v: View) {
        val popupMenu = PopupMenu(this, v)
        popupMenu.menuInflater.inflate(R.menu.activity_option_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener {item ->
            when (item.itemId) {
                R.id.menu_item_1 -> {
                    showToast("Option 1 selected")
                    true
                }
                R.id.menu_item_2 -> {
                    showToast("Option 2 Selected")
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

    private fun showContextMenu(v: View) {
        val popupMenu = PopupMenu(this, v)
        popupMenu.menuInflater.inflate(R.menu.activity_context_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener {item ->
            when (item.itemId) {
                R.id.context_item_1 -> {
                    showToast("Context Option 1 selected")
                    true
                }
                R.id.context_item_2 -> {
                    showToast("Context Option 2 Selected")
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}