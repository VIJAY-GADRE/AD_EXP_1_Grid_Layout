package com.example.exp_7

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageSlider = findViewById<ImageSlider>(R.id.img_slider)
        val slideModels = ArrayList<SlideModel>()

        slideModels.add(SlideModel(R.drawable.image1, ScaleTypes.FIT))
        slideModels.add(SlideModel(R.drawable.image2, ScaleTypes.FIT))
        slideModels.add(SlideModel(R.drawable.image3, ScaleTypes.FIT))
        slideModels.add(SlideModel(R.drawable.image4, ScaleTypes.FIT))
        imageSlider.setImageList(slideModels, ScaleTypes.FIT)
    }
}