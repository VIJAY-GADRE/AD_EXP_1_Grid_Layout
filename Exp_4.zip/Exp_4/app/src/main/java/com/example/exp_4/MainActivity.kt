package com.example.exp_4

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerSubject: Spinner
    private lateinit var radioGroupGender: RadioGroup
    private lateinit var checkBoxBachelor: CheckBox
    private lateinit var checkBoxMasters: CheckBox
    private lateinit var buttonSubmit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerSubject = findViewById(R.id.spinner_subject)
        radioGroupGender = findViewById(R.id.radio_button_group_gender)
        checkBoxBachelor = findViewById(R.id.checkbox_bachelors)
        checkBoxMasters = findViewById(R.id.checkbox_masters)
        buttonSubmit = findViewById(R.id.button_submit)

        val subjects = listOf("Mathematics", "Science", "History")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subjects)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSubject.adapter = adapter

        buttonSubmit.setOnClickListener {
            submitForm()
        }
    }

    private fun submitForm() {
        val selectedSubject = spinnerSubject.selectedItem.toString()

        val selectedGenderID = radioGroupGender.checkedRadioButtonId
        val selectedGender = findViewById<RadioButton>(selectedGenderID)
        val gender = selectedGender.text.toString()

        val qualification = StringBuilder()
        if (checkBoxBachelor.isChecked) {
            qualification.append("Bachelor Degree.")
        }
        if (checkBoxMasters.isChecked) {
            qualification.append("Masters Degree.")
        }
        if (qualification.length > 0) {
            qualification.delete(qualification.length - 2, qualification.length)
        }

        val intent = Intent(this, DisplayData::class.java).apply{
            putExtra("subject", selectedSubject)
            putExtra("gender", gender)
            putExtra("qualification", qualification.toString())
        }
        startActivity(intent)
    }
}