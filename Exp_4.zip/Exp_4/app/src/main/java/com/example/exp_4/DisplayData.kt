package com.example.exp_4

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DisplayData : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_data)

        val textViewDisplayData: TextView = findViewById(R.id.text_view_data_display)
        val extras: Bundle? = intent.extras
        if (extras != null) {
            val subject = extras.getString("subject")
            val gender = extras.getString("gender")
            val qualifications = extras.getString("qualification")
            val message = "Subject: $subject \nGender: $gender \nQualification: $qualifications"
            textViewDisplayData.text = message
        }
    }
}